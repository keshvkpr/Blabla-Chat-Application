package com.example.chatapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class ChatActivity : AppCompatActivity() {

    private lateinit var chatRecyclerView: RecyclerView
    private lateinit var messageBox: EditText
    private lateinit var sendButton: ImageView

    private lateinit var messageAdapter: messageAdapter
    private lateinit var messageList: ArrayList<Message>

    private lateinit var mDbRef: DatabaseReference

    //unique room for both for privacy
    var recieverRoom: String? = null
    var senderRoom: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        val name = intent.getStringExtra("name")
        val recieveruid = intent.getStringExtra("uid")

        val senderuid = FirebaseAuth.getInstance().currentUser?.uid
        mDbRef = FirebaseDatabase.getInstance().getReference()

        senderRoom = recieveruid + senderuid
        recieverRoom = senderuid + recieveruid

        supportActionBar?.title = name

        chatRecyclerView = findViewById(R.id.chatrecyclerView)
        messageBox = findViewById(R.id.messageBox)
        sendButton =  findViewById(R.id.sendbutton)

        messageList = ArrayList()
        messageAdapter = messageAdapter(this, messageList)

        chatRecyclerView.layoutManager = LinearLayoutManager(this)
        chatRecyclerView.adapter = messageAdapter

        //for adding data to recyclerview
        mDbRef.child("chats").child(senderRoom!!)
            .child("messages").addValueEventListener(object: ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {

                    //clear previous value to avoid doubling of messages
                    messageList.clear()

                    for(postSnapshot in snapshot.children){ // to get all the children of snapshot & creating messages using postsnapshot
                        val message = postSnapshot.getValue(Message::class.java)

                        //adding message to message list
                        messageList.add(message!!)
                    }
                    //notifying to adapter
                    messageAdapter.notifyDataSetChanged()

                }

                override fun onCancelled(error: DatabaseError) {
                }

            })

        sendButton.setOnClickListener{

            //send message to database and from that to different users
            val message = messageBox.text.toString() //getting the value from message box
            val messageobj = Message(message,senderuid) //from class message.kt

            //nodes of chat
            mDbRef.child("chats").child(senderRoom!!)
                .child("messages").push().setValue(messageobj)
                .addOnSuccessListener { //creates new nodes everytime when this push is called
                    mDbRef.child("chats").child(recieverRoom!!)
                        .child("messages").push().setValue(messageobj)
                }
            messageBox.setText("")
        }

    }
}