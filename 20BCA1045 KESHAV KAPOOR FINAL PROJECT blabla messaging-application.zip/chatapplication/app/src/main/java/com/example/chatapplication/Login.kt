package com.example.chatapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class Login : AppCompatActivity() {

    private var editemail: EditText? = null
    private var editpassword: EditText? = null
    private var btnlogin: Button? = null
    private var btnsignup: Button? = null

    private lateinit var mAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        supportActionBar?.hide()

        editemail = findViewById(R.id.edit_email)
        editpassword = findViewById(R.id.edit_password)
        btnlogin = findViewById(R.id.btnLogin)
        btnsignup = findViewById(R.id.btnSignup)

        mAuth = FirebaseAuth.getInstance()
        
        btnsignup?.setOnClickListener{
            val intent = Intent( this, Signup::class.java)
            startActivity(intent)
        }
        
        btnlogin?.setOnClickListener{
            val email = editemail?.text.toString()
            val password = editpassword?.text.toString()
            
            login(email,password)
        }
    }

    private fun login(email: String, password: String) {
        mAuth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    //jumping to home
                    val intent = Intent(this@Login, MainActivity::class.java)
                    finish()
                    startActivity(intent)
                }
                else {
                    Toast.makeText(this@Login, "User does not exist!", Toast.LENGTH_SHORT).show()
                }
            }
    }
}