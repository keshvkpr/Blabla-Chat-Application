package com.example.chatapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class Signup : AppCompatActivity() {

    private var editname: EditText? = null
    private var editemail: EditText? = null
    private var editpassword: EditText? = null
    private var btnsignup: Button? = null

    private lateinit var mAuth: FirebaseAuth
    private lateinit var mDbRef: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        supportActionBar?.hide()

        editname = findViewById(R.id.edit_name)
        editemail = findViewById(R.id.edit_email)
        editpassword = findViewById(R.id.edit_password)
        btnsignup = findViewById(R.id.btnSignup)

        mAuth = FirebaseAuth.getInstance()

        btnsignup?.setOnClickListener {
            val name = editname?.text.toString()
            val email = editemail?.text.toString()
            val password = editpassword?.text.toString()

            signup(name,email,password)
        }
    }

    private fun signup(name: String, email: String, password: String){
        mAuth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) {
                if (it.isSuccessful) {
                    //adding data to database
                    addUserToDatabase(name,email,mAuth.currentUser?.uid!!)
                    //jumping to home
                    val intent = Intent(this@Signup, MainActivity::class.java)
                    finish()
                    startActivity(intent)
                }
                else {
                    Toast.makeText(this@Signup, "Some error occurred!", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun addUserToDatabase(name: String, email: String, uid: String){
        //before making this function, i added database to store the data
        //of the users using realtime dtabase from firebase
        mDbRef = FirebaseDatabase.getInstance().getReference() //ref of database
        //child will add node to database //have to pass the pass ie uid
        mDbRef.child("user").child(uid).setValue(User(name,email,uid))
    }
}