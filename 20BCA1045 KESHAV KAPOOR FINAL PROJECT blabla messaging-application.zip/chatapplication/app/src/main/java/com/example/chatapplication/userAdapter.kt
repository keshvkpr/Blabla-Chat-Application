package com.example.chatapplication

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.ktx.Firebase

//The Adapter provides access to the data items.
// The Adapter is also responsible for making a View for each item in the data set
class userAdapter(val context: Context, val userlist: ArrayList<User>):
    RecyclerView.Adapter<userAdapter.UserViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        //creating a view holder that will hold the names of people in chat
        val view: View = LayoutInflater.from(context).inflate(R.layout.user_layout, parent, false)
        return UserViewHolder(view)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val currentUser = userlist[position]
        //holder needed to inflate the arraylist
        holder.textname.text = currentUser.name //will show name of current user

        holder.itemView.setOnClickListener{
            val intent = Intent(context, ChatActivity::class.java)

            //send info from this to chat page
            intent.putExtra("name", currentUser.name)
            intent.putExtra("uid", currentUser.uid)

            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        return userlist.size
    }

    class UserViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        val textname = itemView.findViewById<TextView>(R.id.txt_name)
    }
}